import React from 'react';
import './StackLL.css';

export default function StackLL() {
    return (
        <div className="stack-linked-list-implementation">
            <div className="title">
                <hr /><h2 className="font-weight-bold">Stack</h2><hr />
            </div>
        </div>
    )
}
