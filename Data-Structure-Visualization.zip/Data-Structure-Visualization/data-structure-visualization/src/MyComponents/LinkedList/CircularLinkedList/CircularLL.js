import React from 'react';

export default function CircularLL() {
    return (
        <div className="circular-linked-list">
            <div className="title">
                <hr /><h2 className="font-weight-bold">Circular Linked List</h2><hr />
            </div>
        </div>
    )
}
