import React from 'react';
import './QueueLL.css';

export default function QueueLL() {
    return (
        <div className="queue-linked-list-implementation">
            <div className="title">
                <hr /><h2 className="font-weight-bold">Queue</h2><hr />
            </div>
        </div>
    )
}
