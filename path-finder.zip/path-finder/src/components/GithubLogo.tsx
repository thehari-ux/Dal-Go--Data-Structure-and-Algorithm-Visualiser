export const GithubLogo = () => {
  return (
    <img
      src="/assets/github.png"
      className="h-[18px] w-[18px] mr-2 object-contain"
    />
  );
};
