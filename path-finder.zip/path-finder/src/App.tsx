import GridBoard from "./components/GridBoard";

const App = () => {
  return (
    <>
      <GridBoard />
    </>
  );
};

export default App;
